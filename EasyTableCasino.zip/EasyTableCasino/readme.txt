=== Easy Casino Plugin ===
Contributors: calln
Donate link: not set up yet
Tags: Easy Casino Table, Easy table, Casino table
Requires at least: 5.1
Tested up to: 5.2
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
This is a easy table creator with a review system built into it. 
 
== Description ==

This is a link to our company site were the description is located http://mediaclever.se/plugin/

== Installation ==
 
This section describes how to install the plugin and get it working.

1. Activate the plugin through the 'Plugins' menu in WordPress
 
== Frequently Asked Questions ==
 
= A question that someone might have =
 
An answer to that question.
 
= What about foo bar? =
 
Answer to foo bar dilemma.
 
== Screenshots ==
 
1. /plugin-directory/screenshot-1.png
 
== Changelog ==
 
= 1.0 =
* A change since the previous version.
* Another change.
 
= 0.5 =
* List versions from most recent at top to oldest at bottom.
 
== Upgrade Notice ==
 
= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.
 
= 0.5 =
This version fixes a security related bug.  Upgrade immediately.
 
